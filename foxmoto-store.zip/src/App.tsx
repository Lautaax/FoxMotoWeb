import React, { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import Store from './Store';
import Checkout from './Checkout';

interface Product {
  sku: string;
  title: string;
  price: string;
  stock: string;
  img: string | null;
}

interface SyncProgress {
  current_page: number;
  total_products: number;
  status: 'idle' | 'syncing' | 'error';
}

interface CartItem {
  product: Product;
  quantity: number;
}

export default function App() {
  const [products, setProducts] = useState<Product[]>(() => {
    const cached = localStorage.getItem('foxmoto_products');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error('Error parsing cached products', e);
      }
    }
    return [];
  });
  const [progress, setProgress] = useState<SyncProgress>({ current_page: 0, total_products: 0, status: 'idle' });
  const [loading, setLoading] = useState(() => {
    return !localStorage.getItem('foxmoto_products');
  });
  const [error, setError] = useState<string | null>(null);
  
  // Load cart from localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('foxmoto_cart');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing cart from localStorage', e);
      }
    }
    return [];
  });

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('foxmoto_cart', JSON.stringify(cart));
  }, [cart]);

  const fetchProducts = () => {
    fetch('/api/products')
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch products');
        return res.json();
      })
      .then(data => {
        setProducts(data.products);
        if (data.products && data.products.length > 0) {
          localStorage.setItem('foxmoto_products', JSON.stringify(data.products));
        }
        setProgress(data.progress);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        // Only show error if we don't have cached products
        if (products.length === 0) {
          setError(err.message);
        }
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchProducts();
    
    const interval = setInterval(() => {
      if (progress.status === 'syncing' || loading) {
        fetchProducts();
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [progress.status, loading]);

  const getStockNumber = (stockStr: string) => {
    if (!stockStr) return 0;
    if (stockStr.toLowerCase().includes('ilimitado') || stockStr.toLowerCase().includes('ilimitada')) return Infinity;
    const num = parseInt(stockStr.replace(/[^0-9]/g, ''), 10);
    return isNaN(num) ? 0 : num;
  };

  return (
    <>
      <Toaster position="top-center" richColors />
      <Routes>
        <Route 
          path="/" 
          element={
            <Store 
              products={products} 
              setProducts={setProducts}
              cart={cart}
              setCart={setCart}
              getStockNumber={getStockNumber}
              progress={progress}
              loading={loading}
              error={error}
            />
          } 
        />
        <Route 
          path="/checkout" 
          element={
            <Checkout 
              cart={cart}
              setCart={setCart}
              setProducts={setProducts}
              getStockNumber={getStockNumber}
            />
          } 
        />
      </Routes>
    </>
  );
}
