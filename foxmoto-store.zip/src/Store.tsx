import React, { useEffect, useState, useMemo } from 'react';
import { ShoppingCart, Search, Package, Loader2, AlertCircle, RefreshCw, X, Plus, Minus, ChevronLeft, ChevronRight, Trash2, Filter, ArrowUpDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const KNOWN_CATEGORIES = [
  'CASCO', 'ACEITE', 'BATERIA', 'CUBIERTA', 'NEUMATICO', 'FILTRO', 
  'TRANSMISION', 'PASTILLA', 'BUJIA', 'ESPEJO', 'OPTICA', 'FARO', 
  'MANUBRIO', 'CABLE', 'EMBRAGUE', 'ESCAPE', 'AMORTIGUADOR', 'CADENA', 
  'CORONA', 'PIÑON', 'GUANTE', 'CAMPERA', 'KIT', 'FRENO', 'DISCO', 'LLANTA',
  'RETEN', 'JUNTA', 'BOMBA', 'CARBURADOR', 'CDI', 'REGULADOR', 'ESTATOR',
  'BOBINA', 'RELE', 'DESTELLADOR', 'LAMPARA', 'LED', 'GIRO', 'TABLERO',
  'TRIPA', 'PEDAL', 'PALANCA', 'PUÑO', 'ASIENTO', 'FUNDA', 'PORTAEQUIPAJE',
  'BAUL', 'PARABRISAS', 'DEFENSA', 'ALARMA', 'LINGA', 'CANDADO', 'SOPORTE',
  'RODAMIENTO', 'RULEMAN', 'BUJE', 'EJE', 'RAYO', 'CAMARA', 'LUBRICANTE', 
  'GRASA', 'LIQUIDO', 'REFRIGERANTE', 'LIMPIADOR', 'DESENGRASANTE'
];

const KNOWN_BRANDS = [
  'HONDA', 'YAMAHA', 'SUZUKI', 'KAWASAKI', 'MOTOMEL', 'ZANELLA', 'CORVEN', 
  'BAJAJ', 'GILERA', 'KTM', 'FOX', 'LS2', 'CASTROL', 'MOTUL', 'IPONE', 
  'PIRELLI', 'MICHELIN', 'METZELER', 'NGK', 'YUASA', 'BOSCH', 'W-STANDARD', 'FAR',
  'GUERRERO', 'MONDIAL', 'KEEWAY', 'BENELLI', 'VOGE', 'ROYAL ENFIELD', 'HUSQVARNA',
  'HERO', 'TVS', 'SYM', 'KYMCO', 'MAC', 'HAWK', 'NZI', 'SHIRO', 'MT',
  'AGV', 'SHARK', 'SHOEI', 'ARAI', 'BELL', 'HJC', 'NOLAN', 'KYT', 'SMK', 'ZEUS', 
  'PRO TORK', 'GIVI', 'KAPPA', 'SHAD', 'ALPINESTARS', 'DAINESE', 'REVIT'
];

const getProductCategory = (title: string) => {
  const upperTitle = title.toUpperCase();
  for (const cat of KNOWN_CATEGORIES) {
    if (upperTitle.includes(cat)) return cat;
  }
  return 'OTROS';
};

const getProductBrand = (title: string) => {
  const upperTitle = title.toUpperCase();
  for (const brand of KNOWN_BRANDS) {
    if (upperTitle.includes(brand)) return brand;
  }
  return 'OTRAS MARCAS';
};

export default function Store({ 
  products, 
  setProducts, 
  cart, 
  setCart, 
  getStockNumber, 
  progress, 
  loading, 
  error 
}: any) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('TODAS');
  const [selectedBrand, setSelectedBrand] = useState('TODAS');
  const [sortBy, setSortBy] = useState('relevant'); // relevant, price-asc, price-desc, name-asc, name-desc
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;
  const [isCartOpen, setIsCartOpen] = useState(false);
  const navigate = useNavigate();

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedCategory, selectedBrand, sortBy]);

  const parsePrice = (priceStr: string) => {
    const cleaned = priceStr.replace(/[^0-9,-]+/g, "").replace(/\./g, "").replace(",", ".");
    return parseFloat(cleaned) || 0;
  };

  const { availableCategories, availableBrands, filteredProducts } = useMemo(() => {
    // Extract categories and brands from current products
    const cats = new Set<string>();
    const brnds = new Set<string>();
    
    products.forEach((p: any) => {
      cats.add(getProductCategory(p.title));
      brnds.add(getProductBrand(p.title));
    });

    let filtered = products.filter((p: any) => {
      const matchesSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            p.sku.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'TODAS' || getProductCategory(p.title) === selectedCategory;
      const matchesBrand = selectedBrand === 'TODAS' || getProductBrand(p.title) === selectedBrand;
      
      return matchesSearch && matchesCategory && matchesBrand;
    });

    // Sort
    if (sortBy === 'price-asc') {
      filtered.sort((a: any, b: any) => parsePrice(a.price) - parsePrice(b.price));
    } else if (sortBy === 'price-desc') {
      filtered.sort((a: any, b: any) => parsePrice(b.price) - parsePrice(a.price));
    } else if (sortBy === 'name-asc') {
      filtered.sort((a: any, b: any) => a.title.localeCompare(b.title));
    } else if (sortBy === 'name-desc') {
      filtered.sort((a: any, b: any) => b.title.localeCompare(a.title));
    }

    return {
      availableCategories: Array.from(cats).sort(),
      availableBrands: Array.from(brnds).sort(),
      filteredProducts: filtered
    };
  }, [products, searchTerm, selectedCategory, selectedBrand, sortBy]);

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const currentProducts = filteredProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const addToCart = (product: any) => {
    const stockAvailable = getStockNumber(product.stock);
    if (stockAvailable <= 0) {
      toast.error('Este producto está agotado');
      return;
    }

    setCart((prev: any) => {
      const existing = prev.find((item: any) => item.product.sku === product.sku);
      if (existing) {
        if (existing.quantity >= stockAvailable) {
          toast.error(`Solo hay ${stockAvailable} unidades disponibles`);
          return prev;
        }
        toast.success('Agregaste otra unidad al carrito');
        return prev.map((item: any) => 
          item.product.sku === product.sku 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      toast.success('Producto agregado al carrito');
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (sku: string) => {
    setCart((prev: any) => prev.filter((item: any) => item.product.sku !== sku));
    toast.info('Producto eliminado del carrito');
  };

  const updateQuantity = (sku: string, delta: number) => {
    setCart((prev: any) => prev.map((item: any) => {
      if (item.product.sku === sku) {
        const stockAvailable = getStockNumber(item.product.stock);
        const newQ = item.quantity + delta;
        
        if (newQ > stockAvailable) {
          toast.error(`Solo hay ${stockAvailable} unidades disponibles`);
          return item;
        }
        
        return { ...item, quantity: Math.max(1, newQ) };
      }
      return item;
    }));
  };

  const cartTotal = cart.reduce((sum: number, item: any) => sum + parsePrice(item.product.price) * item.quantity, 0);
  const cartCount = cart.reduce((sum: number, item: any) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans pb-12">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-orange-600 text-white p-2 rounded-lg">
              <Package size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-gray-900">FoxMoto Store</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative hidden sm:flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Buscar repuestos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent w-64 transition-all"
                />
              </div>
              <button 
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className={`p-2 border border-gray-300 rounded-lg transition-colors flex items-center justify-center ${isFilterOpen ? 'bg-orange-50 text-orange-600 border-orange-200' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
                title="Filtros y Orden"
              >
                <Filter size={20} />
              </button>
            </div>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ShoppingCart size={24} />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-orange-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
        {/* Mobile Search */}
        <div className="sm:hidden px-4 pb-4 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Buscar repuestos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent w-full"
            />
          </div>
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className={`p-2 border border-gray-300 rounded-lg transition-colors flex items-center justify-center ${isFilterOpen ? 'bg-orange-50 text-orange-600 border-orange-200' : 'bg-white text-gray-600'}`}
          >
            <Filter size={20} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Filters and Sorting Bar */}
        <div className={`mb-8 bg-white p-4 rounded-xl border border-gray-200 shadow-sm ${isFilterOpen ? 'block' : 'hidden'}`}>
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="w-full md:w-1/3">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Categoría</label>
              <select 
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white"
              >
                <option value="TODAS">Todas las categorías</option>
                {availableCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            
            <div className="w-full md:w-1/3">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Marca</label>
              <select 
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white"
              >
                <option value="TODAS">Todas las marcas</option>
                {availableBrands.map(brand => (
                  <option key={brand} value={brand}>{brand}</option>
                ))}
              </select>
            </div>

            <div className="w-full md:w-1/3">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                <ArrowUpDown size={14} /> Ordenar por
              </label>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white"
              >
                <option value="relevant">Relevancia</option>
                <option value="price-asc">Menor precio</option>
                <option value="price-desc">Mayor precio</option>
                <option value="name-asc">Nombre (A-Z)</option>
                <option value="name-desc">Nombre (Z-A)</option>
              </select>
            </div>
          </div>
          
          {(selectedCategory !== 'TODAS' || selectedBrand !== 'TODAS' || sortBy !== 'relevant' || searchTerm !== '') && (
            <div className="mt-4 pt-4 border-t border-gray-100 flex justify-end">
              <button 
                onClick={() => {
                  setSelectedCategory('TODAS');
                  setSelectedBrand('TODAS');
                  setSortBy('relevant');
                  setSearchTerm('');
                }}
                className="text-sm text-gray-500 hover:text-orange-600 font-medium transition-colors"
              >
                Limpiar filtros
              </button>
            </div>
          )}
        </div>

        {/* Sync Status Banner */}
        {progress.status === 'syncing' && (
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center gap-3 text-blue-700 shadow-sm">
            <RefreshCw className="animate-spin" size={20} />
            <div className="flex-1">
              <p className="font-medium text-sm">Actualizando catálogo en segundo plano...</p>
              <div className="w-full bg-blue-200 rounded-full h-1.5 mt-2 overflow-hidden">
                <div 
                  className="bg-blue-600 h-1.5 rounded-full transition-all duration-500 ease-out" 
                  style={{ width: `${Math.min(100, (progress.current_page / Math.max(1, progress.total_products / 15)) * 100)}%` }}
                ></div>
              </div>
            </div>
            <span className="text-xs font-bold bg-blue-100 px-2 py-1 rounded-full">
              {progress.total_products} items
            </span>
          </div>
        )}

        {/* Products Grid */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="animate-spin text-orange-600 mb-4" size={48} />
            <p className="text-gray-500 font-medium">Cargando catálogo de FoxMoto...</p>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-8 text-center max-w-lg mx-auto mt-10 shadow-sm">
            <AlertCircle className="text-red-500 mx-auto mb-4" size={48} />
            <h3 className="text-lg font-bold text-red-900 mb-2">Error al cargar productos</h3>
            <p className="text-red-700 text-sm">{error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 font-medium transition-colors"
            >
              Intentar de nuevo
            </button>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="mx-auto text-gray-300 mb-4" size={48} />
            <h3 className="text-lg font-medium text-gray-900">No se encontraron productos</h3>
            <p className="text-gray-500 mt-1">Intenta con otra búsqueda.</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {currentProducts.map((product: any) => (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.2 }}
                  key={product.sku}
                  className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow group flex flex-col"
                >
                  <div className="relative aspect-square bg-gray-100 p-4 flex items-center justify-center overflow-hidden">
                    {product.img && !product.img.includes('no-product-image') ? (
                      <img 
                        src={product.img} 
                        alt={product.title} 
                        className="object-contain w-full h-full group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="text-gray-300 flex flex-col items-center">
                        <Package size={48} />
                        <span className="text-xs mt-2 font-medium">Sin imagen</span>
                      </div>
                    )}
                    <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-[10px] font-mono font-bold text-gray-600 border border-gray-200">
                      SKU: {product.sku}
                    </div>
                  </div>
                  
                  <div className="p-4 flex flex-col flex-1">
                    <h3 className="font-medium text-gray-900 text-sm line-clamp-2 mb-2 flex-1" title={product.title}>
                      {product.title}
                    </h3>
                    
                    <div className="flex items-end justify-between mt-auto pt-4">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Precio</p>
                        <p className="text-lg font-bold text-gray-900">{product.price}</p>
                      </div>
                      {getStockNumber(product.stock) > 0 ? (
                        <button 
                          onClick={() => addToCart(product)}
                          className="bg-orange-600 hover:bg-orange-700 text-white p-2 rounded-lg transition-colors shadow-sm flex items-center gap-2"
                        >
                          <ShoppingCart size={18} />
                          <span className="sr-only sm:not-sr-only sm:text-sm font-medium pr-1">Agregar</span>
                        </button>
                      ) : (
                        <div className="bg-gray-100 text-gray-500 px-3 py-2 rounded-lg text-sm font-medium">
                          Agotado
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
                      <span className={`${getStockNumber(product.stock) > 0 ? 'text-green-600' : 'text-red-500'} font-medium flex items-center gap-1`}>
                        <span className={`w-2 h-2 rounded-full ${getStockNumber(product.stock) > 0 ? 'bg-green-500' : 'bg-red-500'}`}></span>
                        {getStockNumber(product.stock) === Infinity ? 'Stock Ilimitado' : product.stock}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="mt-12 flex items-center justify-center gap-4">
                <button 
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="p-2 rounded-lg border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft size={20} />
                </button>
                <div className="text-sm font-medium text-gray-700">
                  Página <span className="text-orange-600 font-bold">{currentPage}</span> de {totalPages}
                </div>
                <button 
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="p-2 rounded-lg border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            )}
          </>
        )}
      </main>

      {/* Shopping Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full sm:w-96 bg-white shadow-2xl z-50 flex flex-col"
            >
              <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="text-orange-600" size={24} />
                  <h2 className="text-lg font-bold text-gray-900">Tu Pedido</h2>
                  <span className="bg-gray-100 text-gray-600 text-xs font-bold px-2 py-1 rounded-full">
                    {cartCount} items
                  </span>
                </div>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
                    <ShoppingCart size={64} className="opacity-20" />
                    <p className="text-sm font-medium">Tu carrito está vacío</p>
                    <button 
                      onClick={() => setIsCartOpen(false)}
                      className="text-orange-600 text-sm font-bold hover:underline"
                    >
                      Seguir comprando
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-end mb-4">
                      <button 
                        onClick={() => {
                          setCart([]);
                          toast.success('Carrito vaciado');
                        }}
                        className="text-sm text-red-500 hover:text-red-700 font-medium flex items-center gap-1 transition-colors"
                      >
                        <Trash2 size={16} />
                        Vaciar carrito
                      </button>
                    </div>
                    <div className="space-y-4">
                      {cart.map((item: any) => (
                        <div key={item.product.sku} className="flex gap-4 bg-white p-3 rounded-xl border border-gray-100 shadow-sm">
                        <div className="w-16 h-16 bg-gray-50 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                          {item.product.img && !item.product.img.includes('no-product-image') ? (
                            <img src={item.product.img} alt={item.product.title} className="object-contain w-full h-full" referrerPolicy="no-referrer" />
                          ) : (
                            <Package size={24} className="text-gray-300" />
                          )}
                        </div>
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <h4 className="text-sm font-medium text-gray-900 line-clamp-2 leading-tight">{item.product.title}</h4>
                            <p className="text-xs text-gray-500 mt-1">{item.product.price}</p>
                          </div>
                          <div className="flex items-center justify-between mt-2">
                            <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-1 border border-gray-200">
                              <button 
                                onClick={() => updateQuantity(item.product.sku, -1)}
                                className="w-6 h-6 flex items-center justify-center text-gray-600 hover:bg-white hover:shadow-sm rounded transition-all"
                              >
                                <Minus size={14} />
                              </button>
                              <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                              <button 
                                onClick={() => updateQuantity(item.product.sku, 1)}
                                disabled={item.quantity >= getStockNumber(item.product.stock)}
                                className="w-6 h-6 flex items-center justify-center text-gray-600 hover:bg-white hover:shadow-sm rounded transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                              >
                                <Plus size={14} />
                              </button>
                            </div>
                            <button 
                              onClick={() => removeFromCart(item.product.sku)}
                              className="text-xs text-red-500 hover:text-red-700 font-medium"
                            >
                              Eliminar
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                    </div>
                  </>
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-4 border-t border-gray-100 bg-gray-50">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-gray-600 font-medium">Total estimado</span>
                    <span className="text-2xl font-bold text-gray-900">
                      {cartTotal.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' })}
                    </span>
                  </div>
                  <button 
                    onClick={() => {
                      setIsCartOpen(false);
                      navigate('/checkout');
                    }}
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-4 rounded-xl transition-colors shadow-sm flex items-center justify-center gap-2"
                  >
                    Completar mis datos
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
