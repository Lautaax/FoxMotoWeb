import express from "express";
import { createServer as createViteServer } from "vite";
import puppeteer from "puppeteer";
import path from "path";

const app = express();
const PORT = 3000;

let cachedProducts: any[] = [];
let isScraping = false;
let scrapeProgress = { current_page: 0, total_products: 0, status: 'idle' };

async function scrapeAllPages() {
  if (isScraping) return;
  isScraping = true;
  scrapeProgress.status = 'syncing';
  scrapeProgress.current_page = 1;
  console.log("Starting full catalog scrape...");
  
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    let currentPage = 1;
    let allProducts: any[] = [];
    let hasMore = true;
    
    while (hasMore) {
      console.log(`Scraping page ${currentPage}...`);
      scrapeProgress.current_page = currentPage;
      
      await page.goto(`https://catalogo.duxsoftware.com.ar/foxmoto?page=${currentPage}`, { waitUntil: 'networkidle2' });
      
      // Scroll down to trigger lazy loading of images
      for (let i = 0; i < 3; i++) {
          await page.evaluate(() => window.scrollBy(0, window.innerHeight));
          await new Promise(r => setTimeout(r, 500));
      }

      const pageProducts = await page.evaluate(() => {
        const elements = Array.from(document.querySelectorAll('*')).filter(el => {
          return el.children.length === 0 && el.textContent?.includes('SKU:');
        });
        
        return elements.map(el => {
          let parent = el.parentElement;
          for(let i=0; i<3; i++) {
              if(parent && parent.parentElement) parent = parent.parentElement;
          }
          
          if (!parent) return null;
          
          const text = parent.innerText;
          const img = parent.querySelector('img')?.src || null;
          
          const lines = text.split('\n').map(l => l.trim()).filter(l => l);
          
          let sku = '';
          let title = '';
          let price = '';
          let stock = '';
          
          for (let i = 0; i < lines.length; i++) {
              if (lines[i].startsWith('SKU:')) sku = lines[i].replace('SKU:', '').trim();
              else if (lines[i].startsWith('$')) price = lines[i];
              else if (lines[i].startsWith('Stock:')) stock = lines[i].replace('Stock:', '').trim();
              else if (lines[i] !== 'Agregar' && lines[i] !== '-') {
                  if (!title) title = lines[i];
              }
          }
          
          return { sku, title, price, stock, img };
        }).filter(p => p && p.sku && p.title && p.price);
      });
      
      if (pageProducts.length === 0) {
        console.log(`No products found on page ${currentPage}. Ending pagination.`);
        hasMore = false;
        break;
      }
      
      allProducts.push(...pageProducts);
      
      // Filter duplicates by SKU and update cache progressively
      const uniqueProducts = Array.from(new Map(allProducts.map(p => [p.sku, p])).values());
      cachedProducts = uniqueProducts;
      scrapeProgress.total_products = cachedProducts.length;
      
      currentPage++;
      
      // Safety limit to avoid infinite loops
      if (currentPage > 50) break;
    }
    
    console.log(`Finished scraping. Total products: ${cachedProducts.length}`);
    scrapeProgress.status = 'idle';
  } catch (err) {
    console.error("Error scraping products:", err);
    scrapeProgress.status = 'error';
  } finally {
    await browser.close();
    isScraping = false;
  }
}

// Start initial scrape in the background
scrapeAllPages();

// Schedule every 30 minutes
setInterval(scrapeAllPages, 30 * 60 * 1000);

async function startServer() {
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.get("/api/products", (req, res) => {
    res.json({
      status: scrapeProgress.status,
      progress: scrapeProgress,
      products: cachedProducts
    });
  });

  app.post("/api/checkout", express.json(), async (req, res) => {
    const { items, customer } = req.body;
    
    if (!items || items.length === 0) {
      return res.status(400).json({ error: "Cart is empty" });
    }
    if (!customer) {
      return res.status(400).json({ error: "Customer details missing" });
    }

    console.log("Processing automated checkout via WhatsApp...");
    
    try {
      // Decrement stock in cachedProducts
      items.forEach((item: any) => {
        const product = cachedProducts.find(p => p.sku === item.product.sku);
        if (product) {
          if (product.stock.toLowerCase().includes('ilimitado') || product.stock.toLowerCase().includes('ilimitada')) {
            // Do nothing
          } else {
            const currentStock = parseInt(product.stock.replace(/[^0-9]/g, ''), 10);
            if (!isNaN(currentStock)) {
              product.stock = `Stock: ${Math.max(0, currentStock - item.quantity)}`;
            }
          }
        }
      });
      
      res.json({ 
        success: true, 
        message: "Checkout automated successfully!",
        orderDetails: {
          success: true,
          url: "whatsapp"
        }
      });
    } catch (error: any) {
      console.error("Checkout automation error:", error);
      res.status(500).json({ error: error.message || "Checkout automation failed" });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
